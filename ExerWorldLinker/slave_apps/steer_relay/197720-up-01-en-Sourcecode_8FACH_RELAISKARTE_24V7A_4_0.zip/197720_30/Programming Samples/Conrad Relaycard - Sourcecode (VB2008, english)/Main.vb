﻿'Imports System.Runtime.Interopservices
Imports System.IO.Ports.SerialPort
Imports System.Media
Imports System.Threading

Public Class Main
    Dim Data_value, Address, Card_count As Byte
    Dim Address_Byte, Command_Byte, Data_byte, CRC_byte As Byte
    Dim Delay_end As Boolean
    Dim Relay_state_backup(0 To 255) As Byte

    Public Sub New()
        InitializeComponent()
        Control.CheckForIllegalCrossThreadCalls = False
    End Sub

    Private Sub Main_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim ports As String()
        Dim port As String
        Me.Refresh()
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor
        Me.Text = "Searching available COM-Ports. Please wait"

        ports = SerialPort1.GetPortNames()           'Search available COM-Ports
        If ports.Length = 0 Then                     'If no COM-Port available
            MsgBox("No COM-PORT found", MsgBoxStyle.Critical)
            End
        End If

        For Each port In ports
            Try
                With SerialPort1
                    .PortName = port
                    .ReadTimeout = Int32.Parse(500)
                    .Open()
                End With

            Catch es As Exception

            Finally
                If SerialPort1.IsOpen = True Then
                    Comport_selector.Items.Add(port)
                End If

                SerialPort1.Close()

            End Try
        Next port

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default

        Me.Text = "Conrad Relaycard V4"
        _SerialPort1.BaudRate = 19200
        _SerialPort1.Parity = IO.Ports.Parity.None
        _SerialPort1.DataBits = 8
        _SerialPort1.StopBits = 1
        _SerialPort1.Handshake = IO.Ports.Handshake.None
    End Sub

    Private Sub Exit_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exit_Button.Click
        Me.Close()
    End Sub

    Private Sub Clear_Textbox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clear_Textbox.Click
        TextBox.Clear()
    End Sub

    Private Sub Init_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Init.Click
        Dim In_buffer(0 To 3), Send_buffer(0) As Byte
        Dim i, x As Int16
        On Error GoTo Errorhandler

        Watchdog_T.Stop()
        Watchdog.Checked = False

        If SerialPort1.IsOpen = False Then
            MsgBox("No Com-Port selected!", MsgBoxStyle.Exclamation)
            GoTo _End
        End If

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor
        SerialPort1.DiscardInBuffer()

        ' Initialize & synchronize cards if needed
        Send_buffer(0) = 1

        For x = 0 To 3
            SerialPort1.Write(Send_buffer, 0, 1)
            sleep(4)
            If SerialPort1.BytesToRead > 3 Then
                Exit For
            End If
        Next

        sleep(1023)                                 ' Wait for feedback

        Send_buffer(0) = 1

        For x = 0 To 3
            SerialPort1.Write(Send_buffer, 0, 1)
        Next

        sleep(1023)                                 ' Wait for feedback

        For i = 0 To 255                            ' Get number of relay cards
            SerialPort1.Read(In_buffer, 0, 4)

            If In_buffer(0) = 1 Then

                If In_buffer(1) = 0 Then             ' if 255 cards connected  (answer of card no. 255 is zero)
                    Card_count = 255
                ElseIf In_buffer(1) > 0 Then

                    Card_count = In_buffer(1) - 1    ' no. of relay cards: ddressbyte of last feedback-frame  - 1 
                End If
                Card_Selector.Maximum = Card_count

                If Card_count = 1 Then              ' Watchdog available, if max 1 relaycard connected. (Can be changed to more cards, but has not been verified)
                    Watchdog.Visible = True
                    WD_Indicator.Visible = True
                    Watchdog.Enabled = True
                Else
                    Watchdog.Enabled = False
                    WD_Indicator.Visible = False
                    Display_WD_error.Visible = False
                End If

                Exit For
            End If
        Next

        If Address = 0 Then
            Label2.Text = "Broadcast"
        Else
            Label2.Text = "card: " & Card_Selector.Value.ToString
        End If
        Label2.Refresh()

        Label3.Text = Card_count.ToString & " relay-card(s) detected"
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default
        All_off.Enabled = True                  ' Enable buttons
        All_on.Enabled = True
        BC_ON.Enabled = True
        BC_OFF.Enabled = True
        Get_Port.Enabled = True
        Set_port.Enabled = True
        Set_single.Enabled = True
        Toggle.Enabled = True
        Del_single.Enabled = True
        Exit_All_Off.Enabled = True

        If Watchdog.Checked = True Then
            Watchdog_T.Start()
        End If
        GoTo _End

Errorhandler:
        MsgBox("No feedback from cards! - Correct COM-Port selected? Conncetion/wiring OK?", MsgBoxStyle.Exclamation)
_End:
    End Sub

    Public Function Send_cmd(ByVal Address_Byte, ByVal Command_Byte, ByVal Data_byte) As Byte
        Dim Send_buffer(0 To 3), In_buffer(0 To 1028) As Byte
        Dim BINARYSTRING As String

        On Error GoTo errorhandler

        Watchdog_T.Stop()
        All_off.Enabled = False                         ' Disable buttons
        All_on.Enabled = False
        BC_ON.Enabled = False
        BC_OFF.Enabled = False
        Get_Port.Enabled = False
        Set_port.Enabled = False
        Set_single.Enabled = False
        Toggle.Enabled = False
        Del_single.Enabled = False
        Exit_All_Off.Enabled = False
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor

        If Watchdog.Checked = True Then
            Watchdog.Enabled = False
            Watchdog_T.Stop()
        End If

        State_List.Items.Clear()                        ' Get state of relay cards for List-Box

        If SerialPort1.IsOpen = False Then
            MsgBox("No Com-Port selcted", MsgBoxStyle.Exclamation)
            GoTo _End
        End If

        Send_buffer(0) = Command_Byte                   'Create command-frame 
        Send_buffer(1) = Address_Byte
        Send_buffer(2) = Data_byte
        Send_buffer(3) = Command_Byte Xor Address_Byte Xor Data_byte 'Calculate "checksum"

        TextBox.Text = ("CMD: " & Command_Byte.ToString & ",  Adr: " & Address_Byte.ToString & ",  Data_byte: " & Data_byte.ToString & ",  CRC: " & Send_buffer(3).ToString)
        SerialPort1.Write(Send_buffer, 0, 4)

        sleep(Card_count * 8 + 10)                      ' delay for executing command & feedback (according to number of connected cards)
        SerialPort1.DiscardOutBuffer()
        SerialPort1.DiscardInBuffer()

GetSchaltzustände:
        Send_buffer(0) = 2                               ' Get Ports
        Send_buffer(1) = 0                               ' Broadcast
        Send_buffer(2) = 0
        Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)

        SerialPort1.Write(Send_buffer, 0, 4)

        sleep(Card_count * 8 + 10)                      ' delay for executing command & feedback (according to number of connected cards)
        SerialPort1.DiscardOutBuffer()

        For x As Byte = 0 To Card_count - 1
            SerialPort1.Read(In_buffer, 0, 4)
            Relay_state_backup(x) = In_buffer(2)
            BINARYSTRING = Convert.ToString(In_buffer(2), 2)
            BINARYSTRING = BINARYSTRING.PadLeft(8, "0"c) ' convert to binary
            State_List.Items.Add((x + 1).ToString & ": " & vbTab & "dec.: " & In_buffer(2).ToString & vbTab & vbTab & "Bin.:" & BINARYSTRING)
        Next

        All_off.Enabled = True                          ' Enable buttons
        All_on.Enabled = True
        BC_ON.Enabled = True
        BC_OFF.Enabled = True
        Get_Port.Enabled = True
        Set_port.Enabled = True
        Set_single.Enabled = True
        Toggle.Enabled = True
        Del_single.Enabled = True
        Exit_All_Off.Enabled = True
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default

        If Watchdog.Checked = True Then
            Watchdog.Enabled = True
            Watchdog_T.Start()
        End If

        GoTo _End
errorhandler:
        MsgBox("Error executing command!", MsgBoxStyle.Exclamation)
_End:

    End Function

    Private Sub Comport_selector_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Comport_selector.SelectedIndexChanged
        If SerialPort1.IsOpen = True Then
            SerialPort1.Close()                                 ' close com-port
        End If
        SerialPort1.PortName = Comport_selector.SelectedItem    ' select new Com-Port

        All_off.Enabled = False                                 ' Disbale buttons -> Init of cards needed
        All_on.Enabled = False
        BC_ON.Enabled = False
        BC_OFF.Enabled = False
        Get_Port.Enabled = False
        Set_port.Enabled = False
        Set_single.Enabled = False
        Toggle.Enabled = False
        Del_single.Enabled = False
        Exit_All_Off.Enabled = False
        Watchdog.Enabled = False
        SerialPort1.Open()                                      ' open Com-Port
    End Sub

    Private Sub Card_Selector_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Card_Selector.Scroll
        Address = Card_Selector.Value                               ' Choose selected card
        If Address = 0 Then
            Label2.Text = "Broadcast"                               ' Address 0 = Broadcast (send to all cards)
        Else
            Label2.Text = "card: " & Card_Selector.Value.ToString   ' Show selected card
        End If
    End Sub


    Private Sub Form_Close(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.FormClosed
        On Error GoTo Errorhandler
        If Exit_All_Off.Checked And Exit_All_Off.Enabled = True Then   'All relays via Broadcast off on exit
            Address_Byte = 0
            Command_Byte = 3
            Data_byte = 0
            Send_cmd(Address_Byte, Command_Byte, Data_byte)
        End If
        SerialPort1.Close()
Errorhandler:
        End
    End Sub

    Private Sub Watchdog_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Watchdog.CheckedChanged
        If Watchdog.Checked = True Then
            Watchdog_T.Start()                                      ' Watchdog active if selected. 
            WD_Indicator.Visible = True
            WD_Indicator.Enabled = True
        End If
    End Sub

    Private Sub Watchdog_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Watchdog_T.Tick
        Dim Send_buffer(0 To 3), In_buffer(0 To 3), I, x As Byte
        WD_Indicator.Checked = True

        On Error GoTo Errorhandler
        Watchdog_T.Stop()
        Display_WD_error.Visible = False
        SerialPort1.DiscardInBuffer()
        SerialPort1.DiscardOutBuffer()

        ' Check relay switching states if correct
        For x = 0 To Card_count - 1
            Send_buffer(0) = 2                  ' Get states
            Send_buffer(1) = x + 1
            Send_buffer(2) = 0
            Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)
            SerialPort1.Write(Send_buffer, 0, 4)
            sleep(Card_count * 4)
            SerialPort1.Read(In_buffer, 0, 4)

            If Relay_state_backup(x) <> In_buffer(2) Then
                GoTo Errorhandler               ' If actual state <> switched state  => Errorhandler
            End If

        Next

        GoTo _End

Errorhandler:
        SerialPort1.DiscardInBuffer()
        SerialPort1.DiscardOutBuffer()

        Display_WD_error.Visible = True
        Send_buffer(0) = 1

        For x = 0 To 3                          ' synchronize to frame (max 4 x 1 Byte + test if feedback-frame recieved)
            SerialPort1.Write(Send_buffer, 0, 1)
            sleep(4)
            If SerialPort1.BytesToRead > 3 Then
                Exit For
            End If
        Next
        sleep(Card_count * 8)                   ' 8 ms sleep/card (= time for transmiting feedback)


        For x = 0 To Card_count - 1             ' set relays to original states
            sleep(4)
            Send_buffer(0) = 3
            Send_buffer(1) = x + 1
            Send_buffer(2) = Relay_state_backup(x)
            Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)
            SerialPort1.Write(Send_buffer, 0, 4)

        Next
_End:
        sleep(Card_count * 8)                   ' 8 ms sleep/card (= time for transmiting feedback)
        Watchdog_T.Start()
        SerialPort1.DiscardOutBuffer()
        SerialPort1.DiscardInBuffer()
        WD_Indicator.Checked = False

        If Watchdog.Checked = False Then
            WD_Indicator.Visible = False
            Display_WD_error.Visible = False
            Watchdog_T.Stop()                   ' stop watchdog if Watchdog.Checked = False 
        End If
    End Sub

    Public Sub sleep(ByRef Time As Integer)
        Timer1.Interval = Time
        Timer1.Start()
        Do Until Delay_end = True
            System.Threading.Thread.Sleep(1)
            Application.DoEvents()              ' Allow windows messages to be processed
        Loop
        Timer1.Stop()
        Delay_end = False
    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Delay_end = True
    End Sub

    Private Sub Relais_Selector_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Relais_Selector.SelectedValueChanged
        Dim x As Integer
        Data_value = 0
        For x = 0 To 7                          ' calculate data-byte (addressed relays) according to checkboxes
            If Relais_Selector.GetItemChecked(x) = True Then
                Data_value = Data_value + (2 ^ (x))
            End If
            Datenbyte_Display.Text = Data_value.ToString
        Next
    End Sub

    Private Sub All_on_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles All_on.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 255                         ' All relays on
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Set_single_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Set_single.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 6                        ' Set-Single
        Data_byte = Data_value                  ' addressed relays according to checkboxes
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Del_single_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Del_single.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 7                        ' Del-Single
        Data_byte = Data_value                  ' addressed relays according to checkboxes
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Toggle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Toggle.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 8                        ' Toggle
        Data_byte = Data_value                  ' addressed relays according to checkboxes
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Set_port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Set_port.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = Data_value                  ' addressed relays according to checkboxes
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Get_Port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Get_Port.Click
        Address_Byte = 0                        ' selected card / Broadcast
        Command_Byte = 2                        ' Get-Ports
        Data_byte = 0                           ' don't care
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub All_off_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles All_off.Click
        Address_Byte = Address                  ' selected card / Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 0                           ' Rel. 1-8 off
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub BC_ON_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BC_ON.Click
        Address_Byte = 0                        ' Address 0 = Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 255                         ' Rel. 1-8 on
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub

    Private Sub BC_OFF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BC_OFF.Click
        Address_Byte = 0                        ' Address 0 = Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 0                           ' Rel. 1-8 off
        Send_cmd(Address_Byte, Command_Byte, Data_byte)
    End Sub
End Class
