﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.Comport_selector = New System.Windows.Forms.ListBox
        Me.Exit_Button = New System.Windows.Forms.Button
        Me.Init = New System.Windows.Forms.Button
        Me.BC_ON = New System.Windows.Forms.Button
        Me.BC_OFF = New System.Windows.Forms.Button
        Me.TextBox = New System.Windows.Forms.TextBox
        Me.Set_port = New System.Windows.Forms.Button
        Me.Set_single = New System.Windows.Forms.Button
        Me.Del_single = New System.Windows.Forms.Button
        Me.Toggle = New System.Windows.Forms.Button
        Me.Datenbyte_Display = New System.Windows.Forms.Label
        Me.Card_Selector = New System.Windows.Forms.TrackBar
        Me.Label2 = New System.Windows.Forms.Label
        Me.Watchdog_T = New System.Windows.Forms.Timer(Me.components)
        Me.Watchdog = New System.Windows.Forms.CheckBox
        Me.WD_Indicator = New System.Windows.Forms.RadioButton
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Exit_All_Off = New System.Windows.Forms.CheckBox
        Me.Relais_Selector = New System.Windows.Forms.CheckedListBox
        Me.Get_Port = New System.Windows.Forms.Button
        Me.All_off = New System.Windows.Forms.Button
        Me.All_on = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Clear_Textbox = New System.Windows.Forms.Button
        Me.Display_WD_error = New System.Windows.Forms.Label
        Me.State_List = New System.Windows.Forms.ListBox
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Card_Selector, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Comport_selector
        '
        Me.Comport_selector.FormattingEnabled = True
        Me.Comport_selector.Location = New System.Drawing.Point(12, 18)
        Me.Comport_selector.Name = "Comport_selector"
        Me.Comport_selector.ScrollAlwaysVisible = True
        Me.Comport_selector.Size = New System.Drawing.Size(73, 277)
        Me.Comport_selector.TabIndex = 0
        '
        'Exit_Button
        '
        Me.Exit_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Exit_Button.Location = New System.Drawing.Point(678, 315)
        Me.Exit_Button.Name = "Exit_Button"
        Me.Exit_Button.Size = New System.Drawing.Size(93, 40)
        Me.Exit_Button.TabIndex = 1
        Me.Exit_Button.Text = "Exit"
        Me.Exit_Button.UseVisualStyleBackColor = True
        '
        'Init
        '
        Me.Init.Location = New System.Drawing.Point(90, 83)
        Me.Init.Name = "Init"
        Me.Init.Size = New System.Drawing.Size(142, 36)
        Me.Init.TabIndex = 2
        Me.Init.Text = "SETUP (Karten Initialisieren)"
        Me.Init.UseVisualStyleBackColor = True
        '
        'BC_ON
        '
        Me.BC_ON.Enabled = False
        Me.BC_ON.Location = New System.Drawing.Point(90, 121)
        Me.BC_ON.Name = "BC_ON"
        Me.BC_ON.Size = New System.Drawing.Size(142, 36)
        Me.BC_ON.TabIndex = 5
        Me.BC_ON.Text = "Alle Relais per Broadcast anschalten"
        Me.BC_ON.UseVisualStyleBackColor = True
        '
        'BC_OFF
        '
        Me.BC_OFF.Enabled = False
        Me.BC_OFF.Location = New System.Drawing.Point(90, 159)
        Me.BC_OFF.Name = "BC_OFF"
        Me.BC_OFF.Size = New System.Drawing.Size(142, 36)
        Me.BC_OFF.TabIndex = 6
        Me.BC_OFF.Text = "Alle Relais per Broadcast ausschalten"
        Me.BC_OFF.UseVisualStyleBackColor = True
        '
        'TextBox
        '
        Me.TextBox.Location = New System.Drawing.Point(12, 304)
        Me.TextBox.Name = "TextBox"
        Me.TextBox.ReadOnly = True
        Me.TextBox.Size = New System.Drawing.Size(221, 20)
        Me.TextBox.TabIndex = 7
        '
        'Set_port
        '
        Me.Set_port.Enabled = False
        Me.Set_port.Location = New System.Drawing.Point(368, 85)
        Me.Set_port.Name = "Set_port"
        Me.Set_port.Size = New System.Drawing.Size(150, 47)
        Me.Set_port.TabIndex = 11
        Me.Set_port.Text = "SET-PORT (entsprechend Auswahl schalten)"
        Me.Set_port.UseVisualStyleBackColor = True
        '
        'Set_single
        '
        Me.Set_single.Enabled = False
        Me.Set_single.Location = New System.Drawing.Point(368, 135)
        Me.Set_single.Name = "Set_single"
        Me.Set_single.Size = New System.Drawing.Size(150, 47)
        Me.Set_single.TabIndex = 13
        Me.Set_single.Text = "SET-SINGLE (Relais anschalten, ohne Änderung der Restlichen)"
        Me.Set_single.UseVisualStyleBackColor = True
        '
        'Del_single
        '
        Me.Del_single.Enabled = False
        Me.Del_single.Location = New System.Drawing.Point(368, 185)
        Me.Del_single.Name = "Del_single"
        Me.Del_single.Size = New System.Drawing.Size(150, 47)
        Me.Del_single.TabIndex = 14
        Me.Del_single.Text = "DEL-SINGLE  (Relais ausschalten, ohne Änderung der Restlichen)"
        Me.Del_single.UseVisualStyleBackColor = True
        '
        'Toggle
        '
        Me.Toggle.Enabled = False
        Me.Toggle.Location = New System.Drawing.Point(368, 235)
        Me.Toggle.Name = "Toggle"
        Me.Toggle.Size = New System.Drawing.Size(150, 47)
        Me.Toggle.TabIndex = 15
        Me.Toggle.Text = "TOGGLE (gewählte Relais umschalten)"
        Me.Toggle.UseVisualStyleBackColor = True
        '
        'Datenbyte_Display
        '
        Me.Datenbyte_Display.AutoSize = True
        Me.Datenbyte_Display.Location = New System.Drawing.Point(260, 284)
        Me.Datenbyte_Display.Name = "Datenbyte_Display"
        Me.Datenbyte_Display.Size = New System.Drawing.Size(85, 13)
        Me.Datenbyte_Display.TabIndex = 16
        Me.Datenbyte_Display.Text = "Datenbyte (dez.)"
        '
        'Card_Selector
        '
        Me.Card_Selector.AutoSize = False
        Me.Card_Selector.LargeChange = 1
        Me.Card_Selector.Location = New System.Drawing.Point(85, 23)
        Me.Card_Selector.Maximum = 255
        Me.Card_Selector.Name = "Card_Selector"
        Me.Card_Selector.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Card_Selector.Size = New System.Drawing.Size(433, 33)
        Me.Card_Selector.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(91, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Broadcast"
        '
        'Watchdog_T
        '
        Me.Watchdog_T.Interval = 500
        '
        'Watchdog
        '
        Me.Watchdog.AutoSize = True
        Me.Watchdog.Enabled = False
        Me.Watchdog.Location = New System.Drawing.Point(368, 332)
        Me.Watchdog.Name = "Watchdog"
        Me.Watchdog.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Watchdog.Size = New System.Drawing.Size(76, 17)
        Me.Watchdog.TabIndex = 26
        Me.Watchdog.Text = "Watchdog"
        Me.Watchdog.UseVisualStyleBackColor = True
        '
        'WD_Indicator
        '
        Me.WD_Indicator.AutoSize = True
        Me.WD_Indicator.Enabled = False
        Me.WD_Indicator.Location = New System.Drawing.Point(430, 312)
        Me.WD_Indicator.Name = "WD_Indicator"
        Me.WD_Indicator.Size = New System.Drawing.Size(14, 13)
        Me.WD_Indicator.TabIndex = 29
        Me.WD_Indicator.TabStop = True
        Me.WD_Indicator.UseVisualStyleBackColor = True
        Me.WD_Indicator.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(518, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(229, 13)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Schaltzustände (Dez.)       (Bin.: Rel 87654321)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 333)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(153, 13)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Gesendeter Kommandorahmen"
        '
        'Exit_All_Off
        '
        Me.Exit_All_Off.AutoSize = True
        Me.Exit_All_Off.Enabled = False
        Me.Exit_All_Off.Location = New System.Drawing.Point(471, 332)
        Me.Exit_All_Off.Name = "Exit_All_Off"
        Me.Exit_All_Off.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Exit_All_Off.Size = New System.Drawing.Size(201, 17)
        Me.Exit_All_Off.TabIndex = 33
        Me.Exit_All_Off.Text = "Relais bei Programmende abschalten"
        Me.Exit_All_Off.UseVisualStyleBackColor = True
        '
        'Relais_Selector
        '
        Me.Relais_Selector.CheckOnClick = True
        Me.Relais_Selector.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.Relais_Selector.FormattingEnabled = True
        Me.Relais_Selector.Items.AddRange(New Object() {"Relais1", "Relais2", "Relais3", "Relais4", "Relais5", "Relais6", "Relais7", "Relais8"})
        Me.Relais_Selector.Location = New System.Drawing.Point(263, 85)
        Me.Relais_Selector.Name = "Relais_Selector"
        Me.Relais_Selector.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Relais_Selector.Size = New System.Drawing.Size(103, 196)
        Me.Relais_Selector.TabIndex = 34
        '
        'Get_Port
        '
        Me.Get_Port.Enabled = False
        Me.Get_Port.Location = New System.Drawing.Point(90, 197)
        Me.Get_Port.Name = "Get_Port"
        Me.Get_Port.Size = New System.Drawing.Size(142, 36)
        Me.Get_Port.TabIndex = 37
        Me.Get_Port.Text = "Get-Port (Schaltzustände abfragen)"
        Me.Get_Port.UseVisualStyleBackColor = True
        '
        'All_off
        '
        Me.All_off.Enabled = False
        Me.All_off.Location = New System.Drawing.Point(90, 266)
        Me.All_off.Name = "All_off"
        Me.All_off.Size = New System.Drawing.Size(142, 29)
        Me.All_off.TabIndex = 36
        Me.All_off.Text = " Relais 1 - 8 aus"
        Me.All_off.UseVisualStyleBackColor = True
        '
        'All_on
        '
        Me.All_on.Enabled = False
        Me.All_on.Location = New System.Drawing.Point(91, 235)
        Me.All_on.Name = "All_on"
        Me.All_on.Size = New System.Drawing.Size(142, 29)
        Me.All_on.TabIndex = 35
        Me.All_on.Text = "Relais 1 - 8 an"
        Me.All_on.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(217, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(10, 13)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "-"
        '
        'Clear_Textbox
        '
        Me.Clear_Textbox.Location = New System.Drawing.Point(174, 327)
        Me.Clear_Textbox.Name = "Clear_Textbox"
        Me.Clear_Textbox.Size = New System.Drawing.Size(59, 24)
        Me.Clear_Textbox.TabIndex = 39
        Me.Clear_Textbox.Text = "Clear"
        Me.Clear_Textbox.UseVisualStyleBackColor = True
        '
        'Display_WD_error
        '
        Me.Display_WD_error.AutoSize = True
        Me.Display_WD_error.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Display_WD_error.ForeColor = System.Drawing.Color.Red
        Me.Display_WD_error.Location = New System.Drawing.Point(332, 312)
        Me.Display_WD_error.Name = "Display_WD_error"
        Me.Display_WD_error.Size = New System.Drawing.Size(97, 13)
        Me.Display_WD_error.TabIndex = 41
        Me.Display_WD_error.Text = "Fehler erkannt! "
        Me.Display_WD_error.Visible = False
        '
        'State_List
        '
        Me.State_List.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.25!)
        Me.State_List.Location = New System.Drawing.Point(526, 22)
        Me.State_List.Name = "State_List"
        Me.State_List.ScrollAlwaysVisible = True
        Me.State_List.Size = New System.Drawing.Size(245, 290)
        Me.State_List.TabIndex = 46
        Me.State_List.TabStop = False
        '
        'SerialPort1
        '
        Me.SerialPort1.BaudRate = 19200
        Me.SerialPort1.ReadBufferSize = 8192
        Me.SerialPort1.ReceivedBytesThreshold = 2048
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(91, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(317, 13)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Wahl der adressierten Relaiskarte (Broadcast = Alle Relaiskarten) "
        '
        'Timer1
        '
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 358)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.State_List)
        Me.Controls.Add(Me.Display_WD_error)
        Me.Controls.Add(Me.Clear_Textbox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Get_Port)
        Me.Controls.Add(Me.All_off)
        Me.Controls.Add(Me.All_on)
        Me.Controls.Add(Me.Relais_Selector)
        Me.Controls.Add(Me.Exit_All_Off)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.WD_Indicator)
        Me.Controls.Add(Me.Watchdog)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Card_Selector)
        Me.Controls.Add(Me.Datenbyte_Display)
        Me.Controls.Add(Me.Toggle)
        Me.Controls.Add(Me.Del_single)
        Me.Controls.Add(Me.Set_single)
        Me.Controls.Add(Me.Set_port)
        Me.Controls.Add(Me.TextBox)
        Me.Controls.Add(Me.BC_OFF)
        Me.Controls.Add(Me.BC_ON)
        Me.Controls.Add(Me.Init)
        Me.Controls.Add(Me.Exit_Button)
        Me.Controls.Add(Me.Comport_selector)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Main"
        Me.Text = "Conrad Relaisplatine V4"
        CType(Me.Card_Selector, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Comport_selector As System.Windows.Forms.ListBox
    Friend WithEvents Exit_Button As System.Windows.Forms.Button
    Friend WithEvents Init As System.Windows.Forms.Button
    Friend WithEvents BC_ON As System.Windows.Forms.Button
    Friend WithEvents BC_OFF As System.Windows.Forms.Button
    Friend WithEvents TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Set_port As System.Windows.Forms.Button
    Friend WithEvents Set_single As System.Windows.Forms.Button
    Friend WithEvents Del_single As System.Windows.Forms.Button
    Friend WithEvents Toggle As System.Windows.Forms.Button
    Friend WithEvents Datenbyte_Display As System.Windows.Forms.Label
    Friend WithEvents Card_Selector As System.Windows.Forms.TrackBar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Watchdog_T As System.Windows.Forms.Timer
    Friend WithEvents Watchdog As System.Windows.Forms.CheckBox
    Friend WithEvents WD_Indicator As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Exit_All_Off As System.Windows.Forms.CheckBox
    Friend WithEvents Relais_Selector As System.Windows.Forms.CheckedListBox
    Friend WithEvents Get_Port As System.Windows.Forms.Button
    Friend WithEvents All_off As System.Windows.Forms.Button
    Friend WithEvents All_on As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Clear_Textbox As System.Windows.Forms.Button
    Friend WithEvents Display_WD_error As System.Windows.Forms.Label
    Friend WithEvents State_List As System.Windows.Forms.ListBox
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
