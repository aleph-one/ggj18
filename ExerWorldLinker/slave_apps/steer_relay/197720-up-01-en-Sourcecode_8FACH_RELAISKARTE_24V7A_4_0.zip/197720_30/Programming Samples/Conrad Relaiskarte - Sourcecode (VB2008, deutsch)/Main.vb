﻿'Imports System.Runtime.Interopservices
Imports System.IO.Ports.SerialPort
Imports System.Media
Imports System.Threading

Public Class Main
    Dim Data_value, Address_value, Kartenzahl As Byte
    Dim Address_byte, Command_Byte, Data_byte, CRC_byte As Byte
    Dim DelayEnde As Boolean
    Dim Schaltzustands_Backup(0 To 255) As Byte


    Public Sub New()
        ' Dieser Aufruf ist für den Windows Form-Designer erforderlich.
        InitializeComponent()
        ' Fügen Sie Initialisierungen nach dem InitializeComponent()-Aufruf hinzu.
        Control.CheckForIllegalCrossThreadCalls = False
    End Sub

    Private Sub Main_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim ports As String()
        Dim port As String
        Me.Refresh()
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor
        Me.Text = "Suche verfügbare COM-Ports. Bitte warten"

        ports = SerialPort1.GetPortNames()           'Nicht belegte COM-Ports des Rechners ermitteln 
        If ports.Length = 0 Then                     'Falls kein COM-Port verfügbar
            MsgBox("Kein COM-PORT gefunden", MsgBoxStyle.Critical)
            End
        End If

        For Each port In ports
            Try
                With SerialPort1
                    .PortName = port
                    .ReadTimeout = Int32.Parse(500)
                    .Open()
                End With

            Catch es As Exception

            Finally
                If SerialPort1.IsOpen = True Then
                    Comport_selector.Items.Add(port)
                End If

                SerialPort1.Close()

            End Try
        Next port

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default

        Me.Text = "Conrad Relaiskarte V4"
        _SerialPort1.BaudRate = 19200
        _SerialPort1.Parity = IO.Ports.Parity.None
        _SerialPort1.DataBits = 8
        _SerialPort1.StopBits = 1
        _SerialPort1.Handshake = IO.Ports.Handshake.None
    End Sub

    Private Sub Exit_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Exit_Button.Click
        Me.Close()
    End Sub

    Private Sub Clear_Textbox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clear_Textbox.Click
        TextBox.Clear()
    End Sub

    Private Sub Init_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Init.Click
        Dim In_buffer(0 To 3), Send_buffer(0) As Byte
        Dim i, x As Int16
        On Error GoTo Errorhandler

        Watchdog_T.Stop()
        Watchdog.Checked = False

        If SerialPort1.IsOpen = False Then
            MsgBox("Kein Com-Port ausgewählt!", MsgBoxStyle.Exclamation)
            GoTo Ende
        End If

        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor
        SerialPort1.DiscardInBuffer()

        ' Initialisierung der Relaiskarten + Synchronistation, falls zuvor Kommandorahmen nicht komplett übertragen wurde
        Send_buffer(0) = 1

        For x = 0 To 3
            SerialPort1.Write(Send_buffer, 0, 1)
            sleep(4)
            If SerialPort1.BytesToRead > 3 Then
                Exit For
            End If
        Next

        sleep(1023)                              ' Zeit für Übermittlung der Rückantworten

        Send_buffer(0) = 1

        For x = 0 To 3
            SerialPort1.Write(Send_buffer, 0, 1)
        Next

        sleep(1023)                             ' Zeit für Übermittlung der Rückantworten

        For i = 0 To 255                        ' Ermittlung der Anzahl der angeschlossenen Relaiskarten
            SerialPort1.Read(In_buffer, 0, 4)

            If In_buffer(0) = 1 Then             ' Kommando 1 wäre Initialisierung der Karte: Kartenzahl + 1

                If In_buffer(1) = 0 Then         ' Falls 255 Karten verbunden 
                    Kartenzahl = 255
                ElseIf In_buffer(1) > 0 Then

                    Kartenzahl = In_buffer(1) - 1  ' Ansosnten ist die Anzahl der Karten Adressbyte des letztem empfangenen Frames - 1 
                End If
                Card_Selector.Maximum = Kartenzahl

                If Kartenzahl = 1 Then          ' Watchdog nur schaltbar, falls max 1 Relaiskarte verbunden. (Kann auf mehrere Karten erweitert werden)
                    Watchdog.Visible = True
                    WD_Indicator.Visible = True
                    Watchdog.Enabled = True
                Else
                    Watchdog.Enabled = False
                    WD_Indicator.Visible = False
                    Display_WD_error.Visible = False
                End If

                Exit For                         ' Abbruch der For Schleife
            End If
        Next

        If Address_value = 0 Then
            Label2.Text = "Broadcast"
        Else
            Label2.Text = "Karte: " & Card_Selector.Value.ToString
        End If
        Label2.Refresh()

        Label3.Text = Kartenzahl.ToString & " Relaiskarte(n) erkannt"
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default
        All_off.Enabled = True                  ' Eingabeknöpfe freigeben
        All_on.Enabled = True
        BC_ON.Enabled = True
        BC_OFF.Enabled = True
        Get_Port.Enabled = True
        Set_port.Enabled = True
        Set_single.Enabled = True
        Toggle.Enabled = True
        Del_single.Enabled = True
        Exit_All_Off.Enabled = True

        If Watchdog.Checked = True Then
            Watchdog_T.Start()
        End If
        GoTo Ende

Errorhandler:
        MsgBox("Keine Antwort! - Wurde der richtige Com-Port ausgewählt? Sind die Karten korrekt angeschlossen?", MsgBoxStyle.Exclamation)
Ende:
    End Sub

    Public Function Senden(ByVal Address_byte, ByVal Command_Byte, ByVal Data_byte) As Byte
        Dim Send_buffer(0 To 3), In_buffer(0 To 1028) As Byte
        Dim BINARYSTRING As String

        On Error GoTo errorhandler
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.WaitCursor
        Watchdog_T.Stop()
        All_off.Enabled = False                  ' eingabeknöpfe freigeben
        All_on.Enabled = False
        BC_ON.Enabled = False
        BC_OFF.Enabled = False
        Get_Port.Enabled = False
        Set_port.Enabled = False
        Set_single.Enabled = False
        Toggle.Enabled = False
        Del_single.Enabled = False
        Exit_All_Off.Enabled = False

        If Watchdog.Checked = True Then
            Watchdog.Enabled = False
            Watchdog_T.Stop()
        End If

        State_List.Items.Clear()                         ' Nach Übermittlung des Kommandorahmens den Schaltzustand zur Anzeige abfragen

        If SerialPort1.IsOpen = False Then
            MsgBox("Kein Com-Port ausgewählt", MsgBoxStyle.Exclamation)
            GoTo Ende
        End If

        Send_buffer(0) = Command_Byte                       'Übernahme des Kommandrahmens in den Sendebuffer
        Send_buffer(1) = Address_byte
        Send_buffer(2) = Data_byte
        Send_buffer(3) = Command_Byte Xor Address_byte Xor Data_byte 'Berechnung der Prüfsumme

        TextBox.Text = ("CMD: " & Command_Byte.ToString & ",  Adr: " & Address_byte.ToString & ",  Data_byte: " & Data_byte.ToString & ",  CRC: " & Send_buffer(3).ToString)
        SerialPort1.Write(Send_buffer, 0, 4)

        sleep(Kartenzahl * 8 + 10)                 ' Zeit zur Ausführung des Kommandorahmens
        SerialPort1.DiscardOutBuffer()
        SerialPort1.DiscardInBuffer()

GetSchaltzustände:
        Send_buffer(0) = 2                               ' Get Ports
        Send_buffer(1) = 0                               ' Broadcast
        Send_buffer(2) = 0
        Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)

        SerialPort1.Write(Send_buffer, 0, 4)

        sleep(Kartenzahl * 8 + 10)                     ' Wartezeit for Antworten
        SerialPort1.DiscardOutBuffer()

        For x As Byte = 0 To Kartenzahl - 1
            SerialPort1.Read(In_buffer, 0, 4)
            Schaltzustands_Backup(x) = In_buffer(2)
            BINARYSTRING = Convert.ToString(In_buffer(2), 2)
            BINARYSTRING = BINARYSTRING.PadLeft(8, "0"c)
            State_List.Items.Add((x + 1).ToString & ": " & vbTab & "Dez.: " & In_buffer(2).ToString & vbTab & vbTab & "Bin.:" & BINARYSTRING)
        Next

        All_off.Enabled = True                          ' Eingabefelder freigeben
        All_on.Enabled = True
        BC_ON.Enabled = True
        BC_OFF.Enabled = True
        Get_Port.Enabled = True
        Set_port.Enabled = True
        Set_single.Enabled = True
        Toggle.Enabled = True
        Del_single.Enabled = True
        Exit_All_Off.Enabled = True


        If Watchdog.Checked = True Then
            Watchdog.Enabled = True
            Watchdog_T.Start()
        End If

        GoTo Ende
errorhandler:
        MsgBox("Fehler bei Ausführung des Kommandos!", MsgBoxStyle.Exclamation)
Ende:
        Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default
    End Function

    Private Sub Comport_selector_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Comport_selector.SelectedIndexChanged
        If SerialPort1.IsOpen = True Then
            SerialPort1.Close()                                  ' Zunächst Com-Port schließen
        End If
        SerialPort1.PortName = Comport_selector.SelectedItem    ' Gewählten Com-Port zuweisen

        All_off.Enabled = False                                 ' Eingabefelder sperren
        All_on.Enabled = False
        BC_ON.Enabled = False
        BC_OFF.Enabled = False
        Get_Port.Enabled = False
        Set_port.Enabled = False
        Set_single.Enabled = False
        Toggle.Enabled = False
        Del_single.Enabled = False
        Exit_All_Off.Enabled = False
        Watchdog.Enabled = False
        SerialPort1.Open()                                      ' Com-Port öffnen
    End Sub

    Private Sub Card_Selector_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Card_Selector.Scroll
        Address_value = Card_Selector.Value                         ' Auswahl der addressierten Relaiskarte
        If Address_value = 0 Then
            Label2.Text = "Broadcast"                               ' Adresse 0 = Broadcast an alle Relaiskarten
        Else
            Label2.Text = "Karte: " & Card_Selector.Value.ToString  ' Anzeige der addressierten Karte
        End If
    End Sub


    Private Sub Form_Close(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.FormClosed
        On Error GoTo Errorhandler
        If Exit_All_Off.Checked And Exit_All_Off.Enabled = True Then   'Alle Relais per Broadcast ausschalten falls gewünscht
            Address_byte = 0
            Command_Byte = 3
            Data_byte = 0
            Senden(Address_byte, Command_Byte, Data_byte)
        End If
        SerialPort1.Close()
Errorhandler:
        End
    End Sub

    Private Sub Watchdog_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Watchdog.CheckedChanged
        If Watchdog.Checked = True Then
            Watchdog_T.Start()                                      ' Falls gewählt Watchdog aktivieren. 
            WD_Indicator.Visible = True
            WD_Indicator.Enabled = True
        End If
    End Sub

    Private Sub Watchdog_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Watchdog_T.Tick
        Dim Send_buffer(0 To 3), In_buffer(0 To 3), I, x As Byte
        WD_Indicator.Checked = True

        On Error GoTo Errorhandler
        Watchdog_T.Stop()
        Display_WD_error.Visible = False
        SerialPort1.DiscardInBuffer()
        SerialPort1.DiscardOutBuffer()

        ' Überprüfung, ob aktuelle Schaltzustände dem gewünschten entsprechen
        For x = 0 To Kartenzahl - 1
            Send_buffer(0) = 2                  ' Schaltzustände abfragen
            Send_buffer(1) = x + 1
            Send_buffer(2) = 0
            Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)
            SerialPort1.Write(Send_buffer, 0, 4)
            sleep(Kartenzahl * 4)
            SerialPort1.Read(In_buffer, 0, 4)

            If Schaltzustands_Backup(x) <> In_buffer(2) Then
                GoTo Errorhandler               ' Falls gemelderter Schaltzustand ungleich des gesetzten => Fehlerbehandlung
            End If

        Next

        GoTo Ende

Errorhandler:
        SerialPort1.DiscardInBuffer()
        SerialPort1.DiscardOutBuffer()

        Display_WD_error.Visible = True
        Send_buffer(0) = 1

        For x = 0 To 3                          ' Synchronistation (max 4 x 1 Byte + jeweils Test, on Antwortframe empfangen)
            SerialPort1.Write(Send_buffer, 0, 1)
            sleep(4)
            If SerialPort1.BytesToRead > 3 Then
                Exit For
            End If
        Next
        sleep(Kartenzahl * 8)                   ' 8 ms sleep/Karte (= Zeit für Übermittlung der Rückantwort)


        For x = 0 To Kartenzahl - 1             ' Schaltzustände wiederherstellen
            sleep(4)
            Send_buffer(0) = 3
            Send_buffer(1) = x + 1
            Send_buffer(2) = Schaltzustands_Backup(x)
            Send_buffer(3) = Send_buffer(0) Xor Send_buffer(1) Xor Send_buffer(2)
            SerialPort1.Write(Send_buffer, 0, 4)

        Next
Ende:
        sleep(Kartenzahl * 8)                   ' 8 ms sleep/Karte (= Zeit für Übermittlung der Rückantwort)
        Watchdog_T.Start()
        SerialPort1.DiscardOutBuffer()
        SerialPort1.DiscardInBuffer()
        WD_Indicator.Checked = False

        If Watchdog.Checked = False Then
            WD_Indicator.Visible = False
            Display_WD_error.Visible = False
            Watchdog_T.Stop()                   ' Watchdog deaktivieren
        End If
    End Sub

    Public Sub sleep(ByRef Time As Integer)
        Timer1.Interval = Time
        Timer1.Start()
        Do Until DelayEnde = True
            ' System.Threading.Thread.Sleep(1)
            Application.DoEvents()              ' Allow windows messages to be processed
        Loop
        Timer1.Stop()
        DelayEnde = False
    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        DelayEnde = True
    End Sub

    Private Sub Relais_Selector_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Relais_Selector.SelectedValueChanged
        Dim x As Integer                        ' Daten-Byte (adressierte Relais) anhand gewählter Checkboxen berechnen
        Data_value = 0
        For x = 0 To 7
            If Relais_Selector.GetItemChecked(x) = True Then
                Data_value = Data_value + (2 ^ (x))
            End If
            Datenbyte_Display.Text = Data_value.ToString
        Next
    End Sub

    Private Sub All_on_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles All_on.Click
        Address_byte = Address_value             ' Gewählte Kartenadresse
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 255                         ' Rel 1-8 on
        'Prüfsumme = 1 wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Set_single_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Set_single.Click
        Address_byte = Address_value             ' Gewählte Kartenadresse
        Command_Byte = 6                        ' Set-Single
        Data_byte = Data_value                 ' mittels "Relaiswahl-Checkboxen" ausgewählte Relais setzen
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Del_single_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Del_single.Click
        Address_byte = Address_value             ' Gewählte KartenAddress_byte
        Command_Byte = 7                        ' Del-Single
        Data_byte = Data_value                 ' mittels "Relaiswahl-Checkboxen" ausgewählte Relais abschalten
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Toggle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Toggle.Click
        Address_byte = Address_value             ' Gewählte Kartenadresse
        Command_Byte = 8                        ' Toggle
        Data_byte = Data_value                 ' mittels "Relaiswahl-Checkboxen" ausgewählte Relais umschalten
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Set_port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Set_port.Click
        Address_byte = Address_value             ' Gewählte Kartenadresse
        Command_Byte = 3                        ' Set-Ports
        Data_byte = Data_value                 ' entsprechend "Relaiswahl-Checkboxen" setzen
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub Get_Port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Get_Port.Click
        Address_byte = 0                         ' Gewählte KartenAdress_byte
        Command_Byte = 2                        ' Get-Ports
        Data_byte = 0                           ' don't care
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub All_off_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles All_off.Click
        Address_byte = Address_value             ' Gewählte KartenAdress_byte
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 0                           ' Rel 1-8 off
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub BC_ON_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BC_ON.Click
        Address_byte = 0                         ' Address_byte 0 = Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 255                         ' Rel 1-8 on
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub

    Private Sub BC_OFF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BC_OFF.Click
        Address_byte = 0                         ' Address_byte 0 = Broadcast
        Command_Byte = 3                        ' Set-Ports
        Data_byte = 0                           ' Rel 1-8 off
        'Prüfsumme wird inerhalb Funktion Senden berechnet
        Senden(Address_byte, Command_Byte, Data_byte)
    End Sub
End Class
